"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";

type Guest = { id: number; name: string; status: "Confirmado" | "Pendente"; };
type Task = { id: number; text: string; done: boolean; };

const wedding = new Date("2026-11-21T14:00:00-03:00");

export default function Dashboard() {
  const [now, setNow] = useState(Date.now());
  const [guests, setGuests] = useState<Guest[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [name, setName] = useState("");
  const [task, setTask] = useState("");

  useEffect(() => {
    const savedGuests = localStorage.getItem("meu-casamento-guests");
    const savedTasks = localStorage.getItem("meu-casamento-tasks");
    if (savedGuests) setGuests(JSON.parse(savedGuests));
    if (savedTasks) setTasks(JSON.parse(savedTasks));
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => localStorage.setItem("meu-casamento-guests", JSON.stringify(guests)), [guests]);
  useEffect(() => localStorage.setItem("meu-casamento-tasks", JSON.stringify(tasks)), [tasks]);

  const countdown = useMemo(() => {
    const diff = Math.max(0, wedding.getTime() - now);
    const sec = Math.floor(diff / 1000);
    return {
      dias: Math.floor(sec / 86400),
      horas: Math.floor((sec % 86400) / 3600),
      minutos: Math.floor((sec % 3600) / 60),
      segundos: sec % 60
    };
  }, [now]);

  function addGuest() {
    const value = name.trim();
    if (!value) return;
    setGuests(g => [...g, { id: Date.now(), name: value, status: "Pendente" }]);
    setName("");
  }

  function addTask() {
    const value = task.trim();
    if (!value) return;
    setTasks(t => [...t, { id: Date.now(), text: value, done: false }]);
    setTask("");
  }

  return (
    <>
      <header className="topbar">
        <div className="container nav">
          <div className="brand">Rafaela &amp; Luan</div>
          <Link className="btn secondary" href="/">Página inicial</Link>
        </div>
      </header>
      <main className="container">
        <section className="section">
          <div className="eyebrow">Meu Casamento</div>
          <h1>Planejamento do nosso grande dia</h1>
          <p className="date">21 de Novembro de 2026 · 14:00</p>
        </section>

        <section className="grid grid4">
          {[
            ["Dias", countdown.dias],
            ["Horas", countdown.horas],
            ["Minutos", countdown.minutos],
            ["Segundos", countdown.segundos]
          ].map(([label, value]) => (
            <div className="card panel" key={label as string}>
              <div className="label">{label}</div>
              <div className="stat">{value}</div>
            </div>
          ))}
        </section>

        <section className="section grid grid2">
          <div className="card panel">
            <h2>Convidados</h2>
            <div className="toolbar">
              <input value={name} onChange={e => setName(e.target.value)} placeholder="Nome do convidado" />
              <button className="btn" onClick={addGuest}>Adicionar</button>
            </div>
            <div>
              {guests.length === 0 && <p className="label">Nenhum convidado cadastrado ainda.</p>}
              {guests.map(g => (
                <div className="item" key={g.id}>
                  <span>{g.name}</span>
                  <button className="badge" onClick={() => setGuests(gs => gs.map(x => x.id === g.id ? {...x, status: x.status === "Confirmado" ? "Pendente" : "Confirmado"} : x))}>{g.status}</button>
                </div>
              ))}
            </div>
          </div>

          <div className="card panel">
            <h2>Tarefas</h2>
            <div className="toolbar">
              <input value={task} onChange={e => setTask(e.target.value)} placeholder="Ex.: Confirmar decoração" />
              <button className="btn" onClick={addTask}>Adicionar</button>
            </div>
            <div>
              {tasks.length === 0 && <p className="label">Nenhuma tarefa cadastrada ainda.</p>}
              {tasks.map(t => (
                <div className="item" key={t.id}>
                  <label style={{display:"flex", gap:10, alignItems:"center", textDecoration:t.done ? "line-through" : "none"}}>
                    <input type="checkbox" checked={t.done} onChange={() => setTasks(ts => ts.map(x => x.id === t.id ? {...x, done: !x.done} : x))} />
                    {t.text}
                  </label>
                  <button className="badge" onClick={() => setTasks(ts => ts.filter(x => x.id !== t.id))}>Excluir</button>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="card panel">
          <h2>Resumo</h2>
          <div className="grid grid4">
            <div><div className="label">Convidados</div><div className="stat">{guests.length}</div></div>
            <div><div className="label">Confirmados</div><div className="stat">{guests.filter(g => g.status === "Confirmado").length}</div></div>
            <div><div className="label">Tarefas</div><div className="stat">{tasks.length}</div></div>
            <div><div className="label">Concluídas</div><div className="stat">{tasks.filter(t => t.done).length}</div></div>
          </div>
        </section>
        <div className="footer">Meu Casamento · Rafaela &amp; Luan</div>
      </main>
    </>
  );
}