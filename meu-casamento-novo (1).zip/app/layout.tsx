import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Meu Casamento | Rafaela & Luan',
  description: 'Planejamento do casamento de Rafaela & Luan',
  manifest: '/manifest.json',
  icons: { icon: '/icon.svg', apple: '/icon.svg' }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}