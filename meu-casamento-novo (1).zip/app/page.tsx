import Link from 'next/link';

export default function Home() {
  return (
    <main className="hero">
      <div className="container">
        <section className="card hero-card">
          <div className="eyebrow">Nosso grande dia</div>
          <div className="names">Rafaela &amp; Luan</div>
          <div className="date">21 de Novembro de 2026 · 14:00</div>
          <div className="divider" />
          <p className="subtitle">
            Um lugar simples e bonito para organizar convidados, orçamento,
            tarefas e todos os detalhes do nosso casamento.
          </p>
          <Link className="btn" href="/dashboard">Começar</Link>
        </section>
      </div>
    </main>
  );
}